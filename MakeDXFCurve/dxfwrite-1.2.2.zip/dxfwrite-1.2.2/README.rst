WARNING
=======

This is an outdated python package, please switch to `ezdxf`: https://pypi.org/project/ezdxf/

Advantage of `ezdxf` over `dxfwrite` is read/write support for DXF versions:

    - R12
    - R2000
    - R2004
    - R2007
    - R2010
    - R2013
    - R2018

Documentation
-------------

http://dxfwrite.readthedocs.io

The source code repository of dxfwrite can be found at GitHub.com:

https://github.com/mozman/dxfwrite.git

Contact
=======

dxfwrite@mozman.at
